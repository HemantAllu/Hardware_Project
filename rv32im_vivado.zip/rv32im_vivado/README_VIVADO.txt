RV32IM 5-stage core - Vivado project for the Nexys A7-100T (xc7a100tcsg324-1)
=============================================================================

Open it
-------
1. Unzip to a SHORT path without spaces (e.g. C:\rv32im_vivado). Vivado on Windows
   has path-length problems with deep folders.
2. Double-click  rv32im.xpr  (or Vivado -> Open Project).
   If Vivado says the project was created with an older version, accept the upgrade.
   The .xpr was written by hand without access to Vivado. If it fails to open or complains
   about the project file, use the fallback (it generates a real project):
       Vivado -> Tools -> Run Tcl Script... -> create_project.tcl

Check that it works - in this order
-----------------------------------
A. Simulation (about a minute):  Flow Navigator -> Run Simulation -> Run Behavioral Simulation.
   In the Tcl console type:  run all
   Expected final lines:   tb_muldiv: 25152 checks, 0 errors
                           TB_MULDIV PASS
   (this exercises every MUL/MULH/MULHSU/MULHU/DIV/DIVU/REM/REMU case incl. divide by zero)

B. Synthesis:        Run Synthesis.
   Expected: completes without errors. Warnings about unused signals are fine.
   If the log says "Cannot open file imem.mem": the two .mem files are not in the
   project (Sources -> Design Sources should list src/mem/imem.mem and dmem.mem).

C. Implementation + bitstream:  Run Implementation, then Generate Bitstream.
   Open "Report Timing Summary": WNS must be >= 0 (clock is 100 MHz).
   If WNS is negative, tell me the failing path - the likely fixes are an extra pipeline
   register in the multiplier (rtl/muldiv_unit.v) or running the core at 50 MHz.

D. On the board:  Open Hardware Manager -> Auto Connect -> Program Device.
   You should see on the 7-segment display, half a second each:
      00123400  FFFFFFFE  00022E09  00000001  FFFFFFF2  FFFFFFFF  (cycle count)
   then interactive mode: A = switches 0-7, B = switches 8-15,
      display = [A*B (16 bit)][A/B low byte][A mod B low byte];   LEDs mirror the switches.
   CPU RESET (the red button) restarts the demo.

Alternatively (batch):  with the project open, Tcl console:  source build_bitstream.tcl

Folder contents
---------------
  rv32im.xpr                 Vivado project (relative paths into src/)
  src/rtl/                   all Verilog (top module: soc_top)
  src/constraints/           nexys_a7_100t.xdc (clock, switches, LEDs, 7-seg, reset)
  src/sim/tb_muldiv.v        self-checking testbench (simulation top)
  src/mem/imem.mem dmem.mem  program image for the board demo (built from extras/sw/demo_board.S)
  create_project.tcl         fallback project generator
  build_bitstream.tcl        optional batch build
  extras/                    software (C/asm, build script), other testbenches (tb_core, tb_soc),
                             golden-model test tools and README_core_and_tests.md
                             (full regression needs iverilog + a RISC-V GCC; see that README)

Notes
-----
* Independent synthesis sanity check (Yosys targeting Xilinx 7-series, NOT Vivado): the whole SoC
  synthesizes with no errors and no latches, about 1.5k LUTs, 750 flip-flops, 4 DSP48E1; the data
  memory maps to distributed RAM and the register file to RAM32M. Vivado's numbers will differ
  somewhat, but this is a tiny design for an XC7A100T. Timing at 100 MHz is not checked by Yosys.
* Nothing in this project has been run in Vivado by me. The Verilog itself was verified with
  Icarus Verilog against a golden model (see extras/README_core_and_tests.md).
* Check the pin numbers in src/constraints/nexys_a7_100t.xdc against Digilent's
  Nexys-A7-100T-Master.xdc if anything on the board misbehaves.
* To run a different program, build it with extras/sw/build.sh and overwrite
  src/mem/imem.mem and dmem.mem with the generated imem.hex / dmem.hex, then re-run synthesis.
