# RV32IM 5-stage pipelined core (Verilog, Vivado / Nexys A7)

Classic IF / ID / EX / MEM / WB pipeline implementing RV32I plus the full RV32M
extension (MUL, MULH, MULHSU, MULHU, DIV, DIVU, REM, REMU), with operand
forwarding, load-use stalls, multi-cycle MUL/DIV stalls and branch flushing.

## Block diagram

```
        +----+   +-------+   +--------------------------+   +-------------+   +----+
 PC --> | IF | ->| IF/ID | ->| ID: decode, imm, regfile | ->| ID/EX       |   |    |
 imem   +----+   +-------+   |     load-use detect      |   +------+------+   |    |
   ^                          +--------------------------+          |          |    |
   |                                                                v          |    |
   |   redirect (taken branch/jump)    +--------------------------------------+    |
   +-----------------------------------| EX: forwarding mux -> ALU / branch cmp    |
                                       |     RV32M unit (stalls EX while busy)     |
                                       +------------------+------------------------+
                                                          v
                                                    +---------+      +--------------+   +---------+
                                                    | EX/MEM  | ---> | MEM: dmem    | ->| MEM/WB  | -> regfile (WB)
                                                    +---------+      +--------------+   +---------+
 Forwarding:  EX/MEM.result --\                                           |
              MEM/WB.data   ---+--> EX operand muxes  <-------------------+
 Hazard unit: load-use / MUL-DIV busy / taken branch / halt  -> stall + flush + bubbles
```

## Hazard handling

| Hazard | Mechanism | Cost |
|---|---|---|
| RAW, producer 1 ahead | forward EX/MEM -> EX | 0 |
| RAW, producer 2 ahead | forward MEM/WB -> EX | 0 |
| RAW, producer 3 ahead | register file write-through (WB -> ID same cycle) | 0 |
| Load-use | stall PC + IF/ID one cycle, bubble into ID/EX, then forward from MEM/WB | 1 cycle |
| MUL / MULH* | front end frozen, bubbles into EX/MEM | 3 stall cycles (4 in EX) |
| DIV / REM* | same | 35 stall cycles (36 in EX) |
| Taken branch / JAL / JALR | resolved in EX, static predict-not-taken, flush IF/ID + ID/EX | 2 cycles |
| EBREAK / ECALL | flush younger instructions, stop fetching (`halted`) | - |

Details worth knowing:
* The M unit latches its operands on the first cycle the instruction is in EX
  (when forwarding is still valid), so a long stall cannot read stale operands.
* Divide-by-zero and overflow follow the RISC-V spec: `x/0 = -1`, `x%0 = x`,
  `INT_MIN/-1 = INT_MIN`, `INT_MIN%-1 = 0`. Latency is data independent.
* Stores take their data through the same forwarding muxes as ALU operands.

## Files

```
rtl/
  rv32im_core.v      pipeline registers and stage logic (top of the CPU)
  control.v          instruction decoder          imm_gen.v   immediates
  alu.v              RV32I ALU                    regfile.v   32x32, write-through
  forwarding_unit.v  EX operand forwarding        hazard_unit.v  stall / flush / bubble control
  muldiv_unit.v      multi-cycle RV32M unit (33x33 multiplier, restoring divider)
  imem.v / dmem.v    async-read memories ($readmemh initialised; per-byte write enables)
  soc_top.v          Nexys A7 top: core + memories + LEDs + 7-seg + switches + cycle counter
  seg7_driver.v      8-digit hex display driver
constraints/nexys_a7_100t.xdc
vivado/ create_project.tcl  build_bitstream.tcl  imem.mem  dmem.mem  (board demo image)
sw/    link.ld  crt0.S  build.sh  demo_board.S  timing_demo.S  examples/*.c (5 C workloads)
tb/    tb_muldiv.v  tb_core.v  tb_soc.v
tools/ rvsim.py (golden RV32IM simulator)  gen_directed.py  gen_random.py
       run_tests.py (regression)  pipeline_trace.py  bin2hex.py
```

Memory map (Harvard): IMEM `0x0000_0000`, DMEM `0x1000_0000`, MMIO `0x2000_0000`
(LED `+0`, 7-seg `+4`, switches `+8` read, cycle counter `+0x10` read; word accesses).

## Run the tests (Icarus Verilog + a RISC-V GCC)

```
python3 tools/run_tests.py                 # unit + directed + SoC + C + 200 random programs
python3 tools/run_tests.py --seeds 1000    # more random programs
python3 tools/run_tests.py --only c        # muldiv | directed | soc | c | random
```
Needs `iverilog` and `riscv64-unknown-elf-gcc` (`apt install iverilog gcc-riscv64-unknown-elf`).

## Build a program and run it

```
sw/build.sh sw/examples/sort.c out          # -> out/imem.hex  out/dmem.hex  out/prog.dis
iverilog -g2005 -o sim tb/tb_core.v rtl/{alu,imm_gen,regfile,control,forwarding_unit,hazard_unit,muldiv_unit,imem,dmem,rv32im_core}.v
vvp sim +IMEM=out/imem.hex +DMEM=out/dmem.hex             # prints stats, registers, first 64 data words
vvp sim +IMEM=... +DMEM=... +VCD=wave.vcd                  # waveform for GTKWave
vvp sim +IMEM=... +DMEM=... +TRACE > t.txt && python3 tools/pipeline_trace.py out/prog.elf t.txt 0 40
```
`sw/timing_demo.S` is a short program that triggers every hazard once - run it through
`+TRACE` / `pipeline_trace.py` to get the cycle-by-cycle table for the timing-diagram
section of the report (the table shows actual execution, including the LU / MD / BR
stall flags).

## Vivado / Nexys A7-100T

The `vivado/` folder has everything needed for the board demo, including prebuilt memory
images (`imem.mem`, `dmem.mem` = `sw/demo_board.S`), so no RISC-V compiler is needed on the PC.

**Quick way (Tcl):** unzip, open Vivado, `Tools -> Run Tcl Script...` and pick
`vivado/create_project.tcl`. It creates `vivado/rv32im_proj`, adds `rtl/*.v`, the two `.mem`
images and the XDC, sets `soc_top` as top (part `xc7a100tcsg324-1`) and `tb_muldiv` as the
simulation top. Then: Run Synthesis -> Run Implementation -> Generate Bitstream ->
Hardware Manager -> Program Device. (`vivado/build_bitstream.tcl` does the same from the Tcl console
and writes `timing_summary.rpt` / `utilization.rpt`.)

**Manual way:** New RTL project, part `xc7a100tcsg324-1`; add every file in `rtl/` as design
sources; add `constraints/nexys_a7_100t.xdc` as constraints; add `vivado/imem.mem` and
`vivado/dmem.mem` as design sources (they are read with `$readmemh`); set `soc_top` as top.

**Demo (`demo_board.S`):** the 7-segment display steps through MUL, MULHU, DIV, REM, signed DIV,
divide-by-zero (0.5 s each) and a measured DIVU cycle count, then switches to interactive mode:
`A = sw[7:0]`, `B = sw[15:8]`, display = `A*B | A/B | A%B`. The CPU RESET button restarts it.

**Your own program:** `sw/build.sh my_prog.c out` (or `.S`) produces `out/imem.hex` / `out/dmem.hex`;
copy them over `vivado/imem.mem` / `vivado/dmem.mem` (same format) and re-run synthesis.
Default memory sizes are 1024 words each (`IMEM_WORDS` / `DMEM_WORDS` parameters of `soc_top`).

**Simulation inside Vivado:** `tb_muldiv` works as is (`Run Simulation`, then `run all`; prints
`TB_MULDIV PASS`). `tb_core` / `tb_soc` read their images from `+IMEM=` / `+DMEM=` plusargs
(or `imem.hex` / `dmem.hex` in the simulation directory); the Icarus flow above is the easier route.

**If synthesis/implementation reports a problem**
* `Cannot open file imem.mem` in the log: the `.mem` files are not part of the project.
* Negative WNS in the timing summary (100 MHz is a bit ambitious for a first try): the usual
  culprits are the multiplier (add a pipeline stage in `muldiv_unit.v`) or the branch-resolve path;
  or run the core from a 50 MHz Clocking Wizard output.
* Display shows nothing: check the XDC pin numbers against Digilent's master XDC.

## What was verified (and what was not)

Verified in simulation (Icarus Verilog 12, strict Verilog-2005 mode, no warnings):
* `muldiv_unit`: 25,152 checks - all 8 ops x 12x12 edge-value pairs + 3,000 random pairs per op,
  results and latency (4 / 36 cycles).
* Directed hazard test (forwarding distances, load-use, sub-word loads/stores, branches, JAL/JALR,
  M-instruction hazards, wrong-path M instructions after a flush, divide by zero) plus a
  table-driven check of every edge pair for all 8 M operations; final state equals the golden model.
* 1,000 random hazard-dense programs (400 instructions each) - final registers, memory and retired
  instruction count identical to the golden model (`tools/rvsim.py`, which decodes machine code
  independently of the RTL).
* Five C workloads (sort, fibonacci incl. recursion, gcd/mod with signed+unsigned DIV/REM, 4x4 matmul,
  prime counting) - state equals the golden model and results were checked against Python.
* Full SoC running the board demo.
* Mutation check: 12 deliberately injected bugs (removed forwarding paths, disabled load-use
  detection, missing flush, no register-file bypass, M unit without forwarded operands, ...) are each
  caught by both the directed and the random tests.

Not verified / known limitations:
* **Not synthesized or run on hardware** - Vivado was not available when this was written. Expect to
  check timing at 100 MHz: the 33x33 multiplier has one register stage (`prod_r`); if it fails,
  add a pipeline stage in `muldiv_unit` (one more state, +1 cycle) or run the core at 50 MHz via a
  clock wizard. Check the pin numbers in the XDC against Digilent's Nexys-A7-100T-Master.xdc.
* Instruction/data memories are asynchronous-read (distributed RAM). Block RAM would add a cycle to
  fetch and loads and needs PC/forwarding changes.
* Only naturally aligned loads/stores; no CSRs, interrupts, traps or FENCE semantics (FENCE = NOP,
  unknown opcodes = NOP).
* Control hazards cost 2 cycles (static not-taken); no branch predictor.
