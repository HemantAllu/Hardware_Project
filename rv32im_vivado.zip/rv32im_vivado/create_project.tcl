# -----------------------------------------------------------------------------
# create_project.tcl  -  FALLBACK: let Vivado generate a genuine project itself.
#
# Use this if double-clicking rv32im.xpr gives any error (the .xpr was written by hand,
# without access to Vivado).  In Vivado:  Tools -> Run Tcl Script... -> pick this file.
# It creates ./rv32im_tcl/rv32im.xpr from the files in ./src (nothing is copied).
# -----------------------------------------------------------------------------
set script_dir [file dirname [file normalize [info script]]]
set proj_dir   $script_dir/rv32im_tcl

create_project rv32im $proj_dir -part xc7a100tcsg324-1 -force

add_files -fileset sources_1 [glob $script_dir/src/rtl/*.v]
add_files -fileset sources_1 [glob $script_dir/src/mem/*.mem]
add_files -fileset constrs_1 $script_dir/src/constraints/nexys_a7_100t.xdc
set_property top soc_top [get_filesets sources_1]

add_files -fileset sim_1 $script_dir/src/sim/tb_muldiv.v
set_property top tb_muldiv [get_filesets sim_1]

update_compile_order -fileset sources_1
puts "Project created in $proj_dir"
puts "Next: Run Simulation (tb_muldiv) -> Run Synthesis -> Run Implementation -> Generate Bitstream."
